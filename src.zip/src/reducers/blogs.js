export function blogs(state = {
  isFetching: false,
  
}, action) {
  switch (action.type) {
    default:
      return state;
  }
}